import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: `
   <p appHighlight>Highlight me!</p> 
  
  `
  
})
export class dirdispComponent1 {
 
}
