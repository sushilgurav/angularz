let test;
export namespace Global {
    export var test: Number = 0;
}