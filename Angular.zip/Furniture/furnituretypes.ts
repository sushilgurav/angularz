import { Details } from './details';

export const furnitures: Details[] = [
  { prod_id: 11, name: 'sofa set`s', prod_price:9000 },
  { prod_id: 12, name: 'Chairs', prod_price:999 },
  { prod_id: 123, name: 'Dining table', prod_price:1500 },
  { prod_id: 151, name: 'study tables', prod_price:1020 },
  { prod_id: 151, name: 'Office chairs', prod_price:1020 },
];