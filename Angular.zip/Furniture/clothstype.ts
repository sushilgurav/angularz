import { Details } from './details';

export const cloths: Details[] = [
  { prod_id: 11, name: 'Denim jean`s', prod_price:900 },
  { prod_id: 12, name: 'T-shirts', prod_price:999 },
  { prod_id: 123, name: 'Shirts', prod_price:1500 },
  { prod_id: 151, name: 'saree', prod_price:1020 },
  { prod_id: 31, name: 'Socks', prod_price:100 },
  { prod_id:411, name: 'Mens shorts', prod_price:1600 },
  { prod_id: 51, name: 'formal Pants', prod_price:1999},
  { prod_id: 91, name: 'F shirts', prod_price:1001 },
  { prod_id: 81, name: 'Kurtha`s', prod_price:1899},
];