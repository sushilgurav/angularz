export class Details {
    prod_id: number;
    name: string;
    prod_price: number;
  }